import { useEffect, useState } from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'

const API_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:8000'

// ─────────────────────────── TYPY ────────────────────────────────

interface Section {
  section_title: string
  section_id:    string
  chunk_index:   number
  content_text:  string
}

interface FullDocument {
  signature:               string
  title?:                  string
  title_full?:             string
  status?:                 string
  year?:                   number
  source_url?:             string
  keywords:                string[]
  related_acts:            string[]
  related_eu_acts:         string[]
  related_uodo_rulings:    string[]
  related_court_rulings:   string[]
  term_decision_type:      string[]
  term_violation_type:     string[]
  term_corrective_measure: string[]
  term_sector:             string[]
  sections:                Section[]
}

interface DocumentViewProps {
  signature: string
  onBack:    () => void
}

// ─────────────────────────── LINKI DO REFERENCJI ─────────────────

/**
 * Generuje URL dla referencji na podstawie sygnatury/oznaczenia.
 *
 * Obsługiwane formaty:
 *   "Dz.U. 2019 poz. 1781"  → ISAP
 *   "EU 2016/679"            → EUR-Lex
 *   "DKN.5131.X.YYYY"        → portal UODO (nowa karta widgetu)
 *   "DS.XXXXX.YYYY"          → j.w.
 *   "II SA/Wa XXXX/YY"       → NSA orzeczenia
 *   "C-XXX/XX"               → TSUE EUR-Lex
 */
function refToUrl(ref: string, type: 'act' | 'eu_act' | 'uodo' | 'court'): string | null {
  if (type === 'act') {
    // "Dz.U. 2019 poz. 1781" → https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20190001781
    const m = ref.match(/Dz\.U\.\s*(\d{4})\s*poz\.\s*(\d+)/)
    if (m) {
      const year = m[1]
      const pos  = m[2].padStart(7, '0')
      return `https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU${year}${pos}`
    }
    return null
  }

  if (type === 'eu_act') {
    // "EU 2016/679" → CELEX 32016R0679
    const m = ref.match(/EU\s+(\d{4})\/(\d+)/)
    if (m) {
      const year = m[1]
      const num  = m[2].padStart(4, '0')
      return `https://eur-lex.europa.eu/legal-content/PL/TXT/?uri=CELEX:3${year}R${num}`
    }
    // "EU YYYY/NNN/UE" (dyrektywy)
    const md = ref.match(/EU\s+(\d{4})\/(\d+)\/UE/)
    if (md) {
      const year = md[1]
      const num  = md[2].padStart(4, '0')
      return `https://eur-lex.europa.eu/legal-content/PL/TXT/?uri=CELEX:3${year}L${num}`
    }
    return null
  }

  if (type === 'uodo') {
    // Decyzja UODO — otwórz w widgecie jako /?doc=SYGNATURA
    return `/?doc=${encodeURIComponent(ref)}`
  }

  if (type === 'court') {
    // "C-XXX/XX" → TSUE EUR-Lex
    const tsue = ref.match(/^C-\d+\/\d+/)
    if (tsue) {
      return `https://curia.europa.eu/juris/liste.jsf?num=${encodeURIComponent(ref)}`
    }
    // Pozostałe → wyszukiwanie w NSA
    return `https://orzeczenia.nsa.gov.pl/cbo/find?cboPhrases=${encodeURIComponent(ref)}`
  }

  return null
}

// ─────────────────────────── HELPERS ─────────────────────────────

function statusClass(status?: string): string {
  if (!status) return 'status-unknown'
  const s = status.toLowerCase()
  if (s.includes('prawomocna') && !s.includes('nie')) return 'status-final'
  if (s.includes('nieprawomocna'))                     return 'status-nonfinal'
  if (s.includes('uchylona'))                          return 'status-repealed'
  return 'status-unknown'
}

// ─────────────────────────── SEKCJA REFERENCJI ───────────────────

function RefGroup({
  title,
  items,
  type,
}: {
  title: string
  items: string[]
  type:  'act' | 'eu_act' | 'uodo' | 'court'
}) {
  if (!items.length) return null
  return (
    <div className="doc-view-refs-group">
      <h4>{title}</h4>
      <ul>
        {items.map((ref) => {
          const url    = refToUrl(ref, type)
          const isUodo = type === 'uodo'
          return (
            <li key={ref}>
              {url ? (
                <a
                  href={url}
                  target={isUodo ? '_blank' : '_blank'}
                  rel="noopener noreferrer"
                  className="doc-ref-link"
                  title={isUodo ? `Otwórz decyzję ${ref}` : `Otwórz źródło: ${ref}`}
                >
                  {ref}
                  <span className="doc-ref-arrow">↗</span>
                </a>
              ) : (
                <span>{ref}</span>
              )}
            </li>
          )
        })}
      </ul>
    </div>
  )
}

// ─────────────────────────── NAWIGACJA SEKCJI ────────────────────

function SectionNav({
  sections,
  active,
  onSelect,
}: {
  sections: Section[]
  active:   number
  onSelect: (i: number) => void
}) {
  if (sections.length <= 1) return null
  return (
    <nav className="doc-view-nav" aria-label="Sekcje dokumentu">
      {sections.map((s, i) => (
        <button
          key={i}
          className={`doc-view-nav-item ${active === i ? 'doc-view-nav-item--active' : ''}`}
          onClick={() => onSelect(i)}
          title={s.section_title || `Sekcja ${i + 1}`}
        >
          <span className="doc-view-nav-num">{i + 1}</span>
          <span className="doc-view-nav-label">
            {s.section_title || `Sekcja ${i + 1}`}
          </span>
        </button>
      ))}
    </nav>
  )
}

// ─────────────────────────── GŁÓWNY KOMPONENT ────────────────────

export function DocumentView({ signature, onBack }: DocumentViewProps) {
  const [doc,     setDoc]     = useState<FullDocument | null>(null)
  const [loading, setLoading] = useState(true)
  const [error,   setError]   = useState<string | null>(null)
  const [active,  setActive]  = useState(0)

  useEffect(() => {
    setLoading(true)
    setError(null)
    setActive(0)
    fetch(`${API_URL}/api/document?signature=${encodeURIComponent(signature)}`)
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`)
        return r.json()
      })
      .then((data: FullDocument) => {
        setDoc(data)
        setLoading(false)
      })
      .catch((e) => {
        setError(String(e))
        setLoading(false)
      })
  }, [signature])

  // Nawigacja klawiaturą ← →
  useEffect(() => {
    if (!doc) return
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') setActive((a) => Math.min(a + 1, doc.sections.length - 1))
      if (e.key === 'ArrowLeft')  setActive((a) => Math.max(a - 1, 0))
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [doc])

  if (loading) return (
    <div className="uodo-rag-widget">
      <div className="rag-skeleton" style={{ height: 60, marginBottom: 8 }} />
      <div className="rag-skeleton" style={{ height: 300 }} />
    </div>
  )

  if (error || !doc) return (
    <div className="uodo-rag-widget">
      <div className="rag-error">Nie udało się wczytać dokumentu: {error}</div>
      <button className="doc-view-back" onClick={onBack}>← Wróć do wyników</button>
    </div>
  )

  const hasRefs = (
    doc.related_acts.length > 0 ||
    doc.related_eu_acts.length > 0 ||
    doc.related_uodo_rulings.length > 0 ||
    doc.related_court_rulings.length > 0
  )

  const section    = doc.sections[active]
  const isFirst    = active === 0
  const isLast     = active === doc.sections.length - 1
  const totalSecs  = doc.sections.length

  return (
    <div className="uodo-rag-widget">

      {/* ── Przycisk powrotu ── */}
      <button className="doc-view-back" onClick={onBack}>
        ← Wróć do wyników
      </button>

      {/* ── Nagłówek ── */}
      <div className="doc-view-header">
        <div className="doc-view-header-top">
          <h1 className="doc-view-signature">{doc.signature}</h1>
          <div className="doc-view-header-meta">
            {doc.status && (
              <span className={`status-badge ${statusClass(doc.status)}`}>
                {doc.status}
              </span>
            )}
            {doc.year && <span className="doc-view-year">{doc.year}</span>}
          </div>
        </div>

        {doc.title_full && <p className="doc-view-title">{doc.title_full}</p>}

        {doc.keywords.length > 0 && (
          <div className="ui-result-tags" style={{ marginTop: '0.75rem' }}>
            {doc.keywords.map((kw, i) => (
              <span key={`${kw}-${i}`} className="ui-result-tag">{kw}</span>
            ))}
          </div>
        )}

        {doc.source_url && (
          <a
            href={doc.source_url}
            target="_blank"
            rel="noopener noreferrer"
            className="doc-view-portal-link"
          >
            Otwórz na portalu orzeczenia.uodo.gov.pl →
          </a>
        )}
      </div>

      {/* ── Body: nawigacja + treść + referencje ── */}
      <div className="doc-view-body">

        {/* ── Nawigacja sekcji ── */}
        <SectionNav
          sections={doc.sections}
          active={active}
          onSelect={setActive}
        />

        {/* ── Treść sekcji ── */}
        <div className="doc-view-content">
          {section && (
            <>
              {/* Nagłówek sekcji z licznikiem */}
              <div className="doc-view-section-header">
                <h2 className="doc-view-section-title">
                  {section.section_title || `Sekcja ${active + 1}`}
                </h2>
                {totalSecs > 1 && (
                  <span className="doc-view-section-counter">
                    {active + 1} / {totalSecs}
                  </span>
                )}
              </div>

              {/* Treść */}
              <div className="doc-view-section-text">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                  {section.content_text}
                </ReactMarkdown>
              </div>

              {/* Poprzednia / Następna */}
              {totalSecs > 1 && (
                <div className="doc-view-section-nav-btns">
                  <button
                    className="doc-view-nav-prev"
                    onClick={() => setActive((a) => a - 1)}
                    disabled={isFirst}
                  >
                    ← Poprzednia sekcja
                  </button>
                  <button
                    className="doc-view-nav-next"
                    onClick={() => setActive((a) => a + 1)}
                    disabled={isLast}
                  >
                    Następna sekcja →
                  </button>
                </div>
              )}
            </>
          )}
        </div>

        {/* ── Referencje ── */}
        {hasRefs && (
          <aside className="doc-view-refs">
            <h3 className="doc-view-refs-title">Powołane dokumenty</h3>
            <RefGroup title="Akty prawne (PL)"   items={doc.related_acts}          type="act"    />
            <RefGroup title="Akty prawne (UE)"   items={doc.related_eu_acts}       type="eu_act" />
            <RefGroup title="Decyzje UODO"        items={doc.related_uodo_rulings}  type="uodo"   />
            <RefGroup title="Orzeczenia sądów"    items={doc.related_court_rulings} type="court"  />
          </aside>
        )}
      </div>
    </div>
  )
}
