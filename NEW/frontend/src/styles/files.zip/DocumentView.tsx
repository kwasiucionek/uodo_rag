import { useEffect, useState } from 'react'
import ReactMarkdown from 'react-markdown'

const API_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:8000'

// ─────────────────────────── TYPY ────────────────────────────────

interface Section {
  section_title: string
  section_id:    string
  chunk_index:   number
  content_text:  string
}

interface FullDocument {
  signature:               string
  title?:                  string
  title_full?:             string
  status?:                 string
  year?:                   number
  source_url?:             string
  keywords:                string[]
  related_acts:            string[]
  related_eu_acts:         string[]
  related_uodo_rulings:    string[]
  related_court_rulings:   string[]
  term_decision_type:      string[]
  term_violation_type:     string[]
  term_corrective_measure: string[]
  term_sector:             string[]
  sections:                Section[]
}

interface DocumentViewProps {
  signature: string
  onBack:    () => void
}

// ─────────────────────────── HELPERS ────────────────────────────

function statusClass(status?: string): string {
  if (!status) return 'status-unknown'
  const s = status.toLowerCase()
  if (s.includes('prawomocna') && !s.includes('nie')) return 'status-final'
  if (s.includes('nieprawomocna'))                     return 'status-nonfinal'
  if (s.includes('uchylona'))                          return 'status-repealed'
  return 'status-unknown'
}

// ─────────────────────────── KOMPONENT ──────────────────────────

export function DocumentView({ signature, onBack }: DocumentViewProps) {
  const [doc,     setDoc]     = useState<FullDocument | null>(null)
  const [loading, setLoading] = useState(true)
  const [error,   setError]   = useState<string | null>(null)
  const [active,  setActive]  = useState(0)   // aktywna sekcja w nawigacji

  useEffect(() => {
    setLoading(true)
    setError(null)
    fetch(`${API_URL}/api/document/${encodeURIComponent(signature)}`)
      .then((r) => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`)
        return r.json()
      })
      .then((data: FullDocument) => {
        setDoc(data)
        setLoading(false)
      })
      .catch((e) => {
        setError(String(e))
        setLoading(false)
      })
  }, [signature])

  if (loading) return (
    <div className="uodo-rag-widget">
      <div className="rag-skeleton" style={{ height: 60, marginBottom: 8 }} />
      <div className="rag-skeleton" style={{ height: 200 }} />
    </div>
  )

  if (error || !doc) return (
    <div className="uodo-rag-widget">
      <div className="rag-error">Nie udało się wczytać dokumentu: {error}</div>
      <button className="doc-view-back" onClick={onBack}>← Wróć do wyników</button>
    </div>
  )

  const hasRefs = (
    doc.related_acts.length > 0 ||
    doc.related_eu_acts.length > 0 ||
    doc.related_uodo_rulings.length > 0 ||
    doc.related_court_rulings.length > 0
  )

  return (
    <div className="uodo-rag-widget">

      {/* ── Przycisk powrotu ── */}
      <button className="doc-view-back" onClick={onBack}>
        ← Wróć do wyników
      </button>

      {/* ── Nagłówek dokumentu ── */}
      <div className="doc-view-header">
        <div className="doc-view-header-top">
          <h1 className="doc-view-signature">{doc.signature}</h1>
          <div className="doc-view-header-meta">
            {doc.status && (
              <span className={`status-badge ${statusClass(doc.status)}`}>
                {doc.status}
              </span>
            )}
            {doc.year && <span className="doc-view-year">{doc.year}</span>}
          </div>
        </div>

        {doc.title_full && (
          <p className="doc-view-title">{doc.title_full}</p>
        )}

        {/* Tagi */}
        {doc.keywords.length > 0 && (
          <div className="ui-result-tags" style={{ marginTop: '0.75rem' }}>
            {doc.keywords.map((kw, i) => (
              <span key={`${kw}-${i}`} className="ui-result-tag">{kw}</span>
            ))}
          </div>
        )}

        {/* Link do portalu */}
        {doc.source_url && (
          <a
            href={doc.source_url}
            target="_blank"
            rel="noopener noreferrer"
            className="doc-view-portal-link"
          >
            Otwórz na portalu orzeczenia.uodo.gov.pl →
          </a>
        )}
      </div>

      <div className="doc-view-body">

        {/* ── Nawigacja sekcji ── */}
        {doc.sections.length > 1 && (
          <nav className="doc-view-nav">
            {doc.sections.map((s, i) => (
              <button
                key={i}
                className={`doc-view-nav-item ${active === i ? 'doc-view-nav-item--active' : ''}`}
                onClick={() => setActive(i)}
              >
                {s.section_title || `Sekcja ${i + 1}`}
              </button>
            ))}
          </nav>
        )}

        {/* ── Treść aktywnej sekcji ── */}
        <div className="doc-view-content">
          {doc.sections.map((s, i) => (
            <div
              key={i}
              className={`doc-view-section ${active === i ? 'doc-view-section--active' : 'doc-view-section--hidden'}`}
            >
              {s.section_title && (
                <h2 className="doc-view-section-title">{s.section_title}</h2>
              )}
              <div className="doc-view-section-text">
                <ReactMarkdown>{s.content_text}</ReactMarkdown>
              </div>
            </div>
          ))}
        </div>

        {/* ── Referencje ── */}
        {hasRefs && (
          <aside className="doc-view-refs">
            <h3 className="doc-view-refs-title">Powołane dokumenty</h3>

            {doc.related_acts.length > 0 && (
              <div className="doc-view-refs-group">
                <h4>Akty prawne (PL)</h4>
                <ul>
                  {doc.related_acts.map((a) => (
                    <li key={a}>{a}</li>
                  ))}
                </ul>
              </div>
            )}

            {doc.related_eu_acts.length > 0 && (
              <div className="doc-view-refs-group">
                <h4>Akty prawne (UE)</h4>
                <ul>
                  {doc.related_eu_acts.map((a) => (
                    <li key={a}>{a}</li>
                  ))}
                </ul>
              </div>
            )}

            {doc.related_uodo_rulings.length > 0 && (
              <div className="doc-view-refs-group">
                <h4>Decyzje UODO</h4>
                <ul>
                  {doc.related_uodo_rulings.map((a) => (
                    <li key={a}>{a}</li>
                  ))}
                </ul>
              </div>
            )}

            {doc.related_court_rulings.length > 0 && (
              <div className="doc-view-refs-group">
                <h4>Orzeczenia sądów</h4>
                <ul>
                  {doc.related_court_rulings.map((a) => (
                    <li key={a}>{a}</li>
                  ))}
                </ul>
              </div>
            )}
          </aside>
        )}
      </div>
    </div>
  )
}
