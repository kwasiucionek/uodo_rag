import { useState } from 'react'
import { Document, Filters } from './api'
import { useSearch } from './hooks/useSearch'
import { DocumentView } from './DocumentView'

// ─────────────────────────── TYPY ────────────────────────────────

export interface UodoRagWidgetProps {
  apiUrl?:   string
  provider?: string
  model?:    string
  useLLM?:   boolean
  onDocumentClick?: (doc: Document) => void
}

// ─────────────────────────── STATUS BADGE ────────────────────────
// Identyczny jak portal — mapowanie statusu na klasę CSS

function statusClass(status?: string): string {
  if (!status) return 'status-unknown'
  const s = status.toLowerCase()
  if (s.includes('prawomocna') && !s.includes('nie')) return 'status-final'
  if (s.includes('nieprawomocna'))                     return 'status-nonfinal'
  if (s.includes('uchylona') || s.includes('uchylony')) return 'status-repealed'
  return 'status-unknown'
}

function statusLabel(status?: string): string {
  if (!status) return ''
  const s = status.toLowerCase()
  if (s.includes('prawomocna') && !s.includes('nie')) return 'prawomocna'
  if (s.includes('nieprawomocna'))                     return 'nieprawomocna'
  if (s.includes('uchylona'))                          return 'uchylona'
  return status
}

// ─────────────────────────── KARTA DOKUMENTU ─────────────────────
// Struktura identyczna jak <article class="doc-list-item"> z result.tsx portalu

function DocumentCard({
  doc,
  onClick,
}: {
  doc:      Document
  onClick?: (doc: Document) => void
}) {
  const isDecision = doc.doc_type === 'uodo_decision'
  const isAct      = doc.doc_type === 'legal_act_article'
  const isGdpr     = doc.doc_type === 'gdpr_article' || doc.doc_type === 'gdpr_recital'

  const handleClick = () => {
    if (onClick) {
      onClick(doc)
    } else if (doc.source_url) {
      window.open(doc.source_url, '_blank', 'noopener')
    }
  }

  const typeClass = isDecision ? '' : isAct ? 'doc-type-act' : 'doc-type-gdpr'

  // Nagłówek: sygnatura lub artykuł
  const title = isDecision
    ? doc.signature
    : isAct
      ? `Art. ${doc.article_num} u.o.d.o.`
      : doc.doc_type === 'gdpr_recital'
        ? doc.article_num
        : `Art. ${doc.article_num} RODO`

  // Data
  const date = doc.year ? String(doc.year) : ''

  return (
    <article
      className={`doc-list-item ${typeClass}`}
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && handleClick()}
      aria-label={`Otwórz dokument ${title}`}
    >
      {/* ── header: sygnatura + status + data ── */}
      <header>
        <span className="doc-signature">{title}</span>
        <div className="doc-meta">
          {doc.graph_relation && (
            <span className="doc-graph-rel">{doc.graph_relation}</span>
          )}
          {isDecision && doc.status && (
            <span className={`status-badge ${statusClass(doc.status)}`}>
              {statusLabel(doc.status)}
            </span>
          )}
          {date && (
            <time dateTime={date}>
              <small>{date}</small>
            </time>
          )}
        </div>
      </header>

      {/* ── main: tytuł + sekcja + fragment ── */}
      <main>
        {isDecision && doc.title_full && (
          <h2>{doc.title_full}</h2>
        )}
        {isDecision && doc.section_title && (
          <span className="doc-section">Sekcja: {doc.section_title}</span>
        )}
        {doc.content_text && (
          <p className="doc-excerpt">
            {doc.content_text.slice(0, 280)}…
          </p>
        )}
      </main>

      {/* ── footer: tagi — identyczne jak .ui-result-tags portalu ── */}
      {isDecision && doc.keywords.length > 0 && (
        <footer>
          <div className="ui-result-tags">
            {doc.keywords.slice(0, 6).map((kw, i) => (
              <span key={`${kw}-${i}`} className="ui-result-tag">
                {kw}
              </span>
            ))}
          </div>
        </footer>
      )}
    </article>
  )
}

// ─────────────────────────── GŁÓWNY KOMPONENT ────────────────────

export function UodoRagWidget({
  provider = 'Ollama',
  model    = 'mistral-large-3:675b-cloud',
  useLLM   = true,
  onDocumentClick,
}: UodoRagWidgetProps) {
  const [query,       setQuery]       = useState('')
  const [filters,     setFilters]     = useState<Filters>({})
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null)

  const {
    docs, tags, answer, searchTime, total,
    loadingDocs, loadingAnswer, error,
    search, stopStream,
  } = useSearch({ provider, model, useLLM })

  const handleSearch = () => {
    if (query.trim()) search(query, filters)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') handleSearch()
  }

  const handleDocClick = (doc: Document) => {
    if (onDocumentClick) {
      onDocumentClick(doc)
    } else if (doc.doc_type === 'uodo_decision' && doc.signature) {
      setSelectedDoc(doc.signature)
    } else if (doc.source_url) {
      window.open(doc.source_url, '_blank', 'noopener')
    }
  }

  if (selectedDoc) {
    return <DocumentView signature={selectedDoc} onBack={() => setSelectedDoc(null)} />
  }

  return (
    <div className="uodo-rag-widget">

      {/* ── Pole wyszukiwania (featured-card) ── */}
      <div className="rag-search-card">
        <h2>Wyszukiwarka decyzji UODO z AI</h2>
        <div className="rag-search-bar">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Wpisz treść, sygnaturę lub temat..."
            className="rag-search-input"
            disabled={loadingDocs}
            aria-label="Wyszukaj decyzje UODO"
          />
          <button
            onClick={handleSearch}
            disabled={loadingDocs || !query.trim()}
            className="rag-search-btn"
          >
            {loadingDocs ? 'Szukam…' : 'Szukaj'}
          </button>
        </div>
      </div>

      {/* ── Błąd ── */}
      {error && (
        <div className="rag-error" role="alert">{error}</div>
      )}

      {/* ── Odpowiedź AI ── */}
      {(answer || loadingAnswer) && (
        <div className="rag-answer">
          <div className="rag-answer-header">
            <span>Odpowiedź AI</span>
            {loadingAnswer && (
              <button onClick={stopStream} className="rag-stop-btn">
                Zatrzymaj
              </button>
            )}
          </div>
          <div className="rag-answer-body">
            {answer}
            {loadingAnswer && <span className="rag-cursor">▋</span>}
          </div>
        </div>
      )}

      {/* ── Statystyki ── */}
      {total > 0 && !loadingDocs && (
        <p className="rag-stats">
          {total} dokumentów · {searchTime.toFixed(2)}s
          {tags.length > 0 && (
            <> · tagi: {tags.slice(0, 5).join(', ')}</>
          )}
        </p>
      )}

      {/* ── Loading skeleton ── */}
      {loadingDocs && (
        <>
          <div className="rag-skeleton" />
          <div className="rag-skeleton" />
          <div className="rag-skeleton" />
        </>
      )}

      {/* ── Lista wyników ── */}
      {!loadingDocs && docs.map((doc, i) => (
        <DocumentCard
          key={doc.doc_id ?? `${doc.signature}-${i}`}
          doc={doc}
          onClick={handleDocClick}
        />
      ))}
    </div>
  )
}
