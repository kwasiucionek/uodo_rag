import { useCallback, useRef, useState } from 'react'
import { api, Document, Filters, SearchResponse } from '../api'

const PER_PAGE = 10

interface SearchState {
  allDocs:      Document[]   // wszystkie wyniki z API
  docs:         Document[]   // wyniki na bieżącej stronie
  tags:         string[]
  answer:       string
  searchTime:   number
  total:        number
  page:         number
  totalPages:   number
  loadingDocs:  boolean
  loadingAnswer: boolean
  error:        string | null
}

const INITIAL_STATE: SearchState = {
  allDocs:       [],
  docs:          [],
  tags:          [],
  answer:        '',
  searchTime:    0,
  total:         0,
  page:          1,
  totalPages:    1,
  loadingDocs:   false,
  loadingAnswer: false,
  error:         null,
}

interface UseSearchOptions {
  provider:  string
  model:     string
  useGraph?: boolean
  useLLM?:   boolean
}

function paginate(allDocs: Document[], page: number): {
  docs: Document[]
  totalPages: number
} {
  const totalPages = Math.max(1, Math.ceil(allDocs.length / PER_PAGE))
  const safePage   = Math.min(Math.max(1, page), totalPages)
  const start      = (safePage - 1) * PER_PAGE
  return {
    docs:       allDocs.slice(start, start + PER_PAGE),
    totalPages,
  }
}

export function useSearch(options: UseSearchOptions) {
  const { provider, model, useGraph = true, useLLM = true } = options

  const [state, setState]  = useState<SearchState>(INITIAL_STATE)
  const stopStreamRef      = useRef<(() => void) | null>(null)
  const lastQueryRef       = useRef<string>('')
  const lastAllDocsRef     = useRef<Document[]>([])

  const stopStream = useCallback(() => {
    stopStreamRef.current?.()
    stopStreamRef.current = null
    setState((s) => ({ ...s, loadingAnswer: false }))
  }, [])

  // ── Zmiana strony (bez ponownego wyszukiwania) ──
  const goToPage = useCallback((page: number) => {
    const allDocs = lastAllDocsRef.current
    const { docs, totalPages } = paginate(allDocs, page)
    setState((s) => ({ ...s, docs, page, totalPages }))
  }, [])

  // ── Wyszukiwanie ──
  const search = useCallback(
    async (query: string, filters: Filters = {}) => {
      if (!query.trim()) return

      stopStream()
      lastQueryRef.current = query

      setState({ ...INITIAL_STATE, loadingDocs: true })

      try {
        // 1. Dekompozycja zapytania
        let searchQuery: string | undefined
        if (useLLM && query.split(' ').length > 3) {
          try {
            const decomposed = await api.decompose(query, provider, model)
            searchQuery = decomposed.search_keywords.slice(0, 3).join(' ')
          } catch {
            // fallback
          }
        }

        // 2. Wyszukiwanie — top_k=50 żeby mieć zapas dla paginacji
        const result: SearchResponse = await api.search({
          query,
          search_query: searchQuery,
          filters,
          use_graph:    useGraph,
          top_k:        50,
        })

        lastAllDocsRef.current = result.docs
        const { docs, totalPages } = paginate(result.docs, 1)

        setState((s) => ({
          ...s,
          allDocs:     result.docs,
          docs,
          tags:        result.tags,
          searchTime:  result.search_time,
          total:       result.total,
          page:        1,
          totalPages,
          loadingDocs: false,
        }))

        // 3. Streaming LLM — tylko pierwsze 8 dokumentów jako kontekst
        if (useLLM && result.docs.length > 0) {
          setState((s) => ({ ...s, answer: '', loadingAnswer: true }))

          stopStreamRef.current = api.streamAnswer(
            { query, docs: result.docs.slice(0, 8), provider, model },
            (token) => setState((s) => ({ ...s, answer: s.answer + token })),
            ()      => setState((s) => ({ ...s, loadingAnswer: false })),
            (msg)   => setState((s) => ({ ...s, loadingAnswer: false, error: msg })),
          )
        }
      } catch (err) {
        setState((s) => ({
          ...s,
          loadingDocs:   false,
          loadingAnswer: false,
          error: err instanceof Error ? err.message : String(err),
        }))
      }
    },
    [provider, model, useGraph, useLLM, stopStream],
  )

  return { ...state, search, stopStream, goToPage }
}
