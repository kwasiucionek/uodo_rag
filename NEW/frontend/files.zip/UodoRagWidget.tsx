import { useState } from 'react'
import ReactMarkdown from 'react-markdown'
import { Document, Filters } from './api'
import { useSearch } from './hooks/useSearch'
import { FiltersPanel } from './FiltersPanel'

// ─────────────────────────── TYPY ────────────────────────────────

export interface UodoRagWidgetProps {
  apiUrl?:   string
  provider?: string
  model?:    string
  useLLM?:   boolean
  onDocumentClick?: (doc: Document) => void
}

// ─────────────────────────── STATUS HELPERS ───────────────────────

function statusClass(status?: string): string {
  if (!status) return 'status-unknown'
  const s = status.toLowerCase()
  if (s.includes('prawomocna') && !s.includes('nie')) return 'status-final'
  if (s.includes('nieprawomocna'))                     return 'status-nonfinal'
  if (s.includes('uchylona'))                          return 'status-repealed'
  return 'status-unknown'
}

function statusLabel(status?: string): string {
  if (!status) return ''
  const s = status.toLowerCase()
  if (s.includes('prawomocna') && !s.includes('nie')) return 'prawomocna'
  if (s.includes('nieprawomocna'))                     return 'nieprawomocna'
  if (s.includes('uchylona'))                          return 'uchylona'
  return status
}

// ─────────────────────────── KARTA DOKUMENTU ─────────────────────

function DocumentCard({
  doc,
  onClick,
}: {
  doc:      Document
  onClick?: (doc: Document) => void
}) {
  const isDecision = doc.doc_type === 'uodo_decision'
  const isAct      = doc.doc_type === 'legal_act_article'

  const title = isDecision
    ? doc.signature
    : isAct
      ? `Art. ${doc.article_num} u.o.d.o.`
      : doc.doc_type === 'gdpr_recital'
        ? doc.article_num
        : `Art. ${doc.article_num} RODO`

  const handleClick = () => {
    if (onClick) {
      onClick(doc)
    } else if (doc.doc_type === 'uodo_decision' && doc.signature) {
      window.open(`/?doc=${encodeURIComponent(doc.signature)}`, '_blank', 'noopener')
    } else if (doc.source_url) {
      window.open(doc.source_url, '_blank', 'noopener')
    }
  }

  return (
    <article
      className="doc-list-item"
      onClick={handleClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && handleClick()}
      aria-label={`Otwórz dokument ${title}`}
    >
      <header>
        <span className="doc-signature">{title}</span>
        <div className="doc-meta">
          {doc.graph_relation && (
            <span className="doc-graph-rel">{doc.graph_relation}</span>
          )}
          {isDecision && doc.status && (
            <span className={`status-badge ${statusClass(doc.status)}`}>
              {statusLabel(doc.status)}
            </span>
          )}
          {doc.year && <time dateTime={String(doc.year)}><small>{doc.year}</small></time>}
        </div>
      </header>

      <main>
        {isDecision && doc.title_full && <h2>{doc.title_full}</h2>}
        {isDecision && doc.section_title && (
          <span className="doc-section">Sekcja: {doc.section_title}</span>
        )}
        {doc.content_text && (
          <p className="doc-excerpt">{doc.content_text.slice(0, 280)}…</p>
        )}
      </main>

      {isDecision && doc.keywords.length > 0 && (
        <footer>
          <div className="ui-result-tags">
            {doc.keywords.slice(0, 6).map((kw, i) => (
              <span key={`${kw}-${i}`} className="ui-result-tag">{kw}</span>
            ))}
          </div>
        </footer>
      )}
    </article>
  )
}

// ─────────────────────────── PAGINACJA ───────────────────────────

function Pagination({
  page,
  totalPages,
  onPage,
}: {
  page:       number
  totalPages: number
  onPage:     (p: number) => void
}) {
  if (totalPages <= 1) return null

  // Pokaż max 7 stron wokół bieżącej
  const pages: (number | '…')[] = []
  const range = (from: number, to: number) =>
    Array.from({ length: to - from + 1 }, (_, i) => from + i)

  if (totalPages <= 7) {
    pages.push(...range(1, totalPages))
  } else {
    pages.push(1)
    if (page > 3)         pages.push('…')
    pages.push(...range(Math.max(2, page - 1), Math.min(totalPages - 1, page + 1)))
    if (page < totalPages - 2) pages.push('…')
    pages.push(totalPages)
  }

  return (
    <nav className="rag-pagination" aria-label="Paginacja wyników">
      <button
        className="rag-page-btn"
        onClick={() => onPage(page - 1)}
        disabled={page === 1}
        aria-label="Poprzednia strona"
      >
        ‹
      </button>

      {pages.map((p, i) =>
        p === '…' ? (
          <span key={`ellipsis-${i}`} className="rag-page-ellipsis">…</span>
        ) : (
          <button
            key={p}
            className={`rag-page-btn ${p === page ? 'rag-page-btn--active' : ''}`}
            onClick={() => onPage(p as number)}
            aria-current={p === page ? 'page' : undefined}
          >
            {p}
          </button>
        )
      )}

      <button
        className="rag-page-btn"
        onClick={() => onPage(page + 1)}
        disabled={page === totalPages}
        aria-label="Następna strona"
      >
        ›
      </button>
    </nav>
  )
}

// ─────────────────────────── AKTYWNE FILTRY ──────────────────────

function ActiveFilters({
  filters,
  onRemove,
}: {
  filters:  Filters
  onRemove: (key: keyof Filters, value?: string) => void
}) {
  const items: { key: keyof Filters; label: string; value?: string }[] = []

  if (filters.status)
    items.push({ key: 'status', label: `Status: ${filters.status}` })
  if (filters.year_from)
    items.push({ key: 'year_from', label: `Od: ${filters.year_from}` })
  if (filters.year_to)
    items.push({ key: 'year_to', label: `Do: ${filters.year_to}` })

  const listKeys: (keyof Filters)[] = [
    'term_decision_type', 'term_sector',
    'term_corrective_measure', 'term_violation_type',
  ]
  for (const key of listKeys) {
    for (const v of (filters[key] as string[] | undefined) ?? []) {
      items.push({ key, label: v, value: v })
    }
  }

  if (!items.length) return null

  return (
    <div className="rag-active-filters">
      {items.map((item, i) => (
        <span key={i} className="rag-active-filter-tag">
          {item.label}
          <button
            onClick={() => onRemove(item.key, item.value)}
            aria-label={`Usuń filtr: ${item.label}`}
          >
            ×
          </button>
        </span>
      ))}
    </div>
  )
}

// ─────────────────────────── GŁÓWNY KOMPONENT ────────────────────

export function UodoRagWidget({
  provider = 'Ollama',
  model    = 'mistral-large-3:675b-cloud',
  useLLM   = true,
  onDocumentClick,
}: UodoRagWidgetProps) {
  const [query,    setQuery]    = useState('')
  const [filters,  setFilters]  = useState<Filters>({})
  const [pending,  setPending]  = useState<Filters>({})   // filtry przed zatwierdzeniem

  const {
    docs, tags, answer, searchTime, total,
    page, totalPages,
    loadingDocs, loadingAnswer, error,
    search, stopStream, goToPage,
  } = useSearch({ provider, model, useLLM })

  const hasResults = total > 0 || loadingDocs

  const handleSearch = (overrideFilters?: Filters) => {
    if (!query.trim()) return
    const f = overrideFilters ?? filters
    setFilters(f)
    search(query, f)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') handleSearch()
  }

  const handleFiltersApply = () => {
    setFilters(pending)
    search(query, pending)
  }

  const handleFiltersReset = () => {
    setPending({})
    setFilters({})
    if (query.trim()) search(query, {})
  }

  const removeFilter = (key: keyof Filters, value?: string) => {
    let next: Filters
    if (value) {
      const current = (filters[key] as string[] | undefined) ?? []
      next = { ...filters, [key]: current.filter((v) => v !== value) || undefined }
      if (!(next[key] as string[]).length) delete next[key]
    } else {
      next = { ...filters }
      delete next[key]
    }
    setFilters(next)
    setPending(next)
    if (query.trim()) search(query, next)
  }

  return (
    <div className="uodo-rag-widget">

      {/* ── Pole wyszukiwania ── */}
      <div className="rag-search-card">
        <h2>Wyszukiwarka decyzji UODO z AI</h2>
        <div className="rag-search-bar">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Wpisz treść, sygnaturę lub temat..."
            className="rag-search-input"
            disabled={loadingDocs}
            aria-label="Wyszukaj decyzje UODO"
          />
          <button
            onClick={() => handleSearch()}
            disabled={loadingDocs || !query.trim()}
            className="rag-search-btn"
          >
            {loadingDocs ? 'Szukam…' : 'Szukaj'}
          </button>
        </div>
      </div>

      {/* ── Błąd ── */}
      {error && <div className="rag-error" role="alert">{error}</div>}

      {/* ── Odpowiedź AI ── */}
      {(answer || loadingAnswer) && (
        <div className="rag-answer">
          <div className="rag-answer-header">
            <span>Odpowiedź AI</span>
            {loadingAnswer && (
              <button onClick={stopStream} className="rag-stop-btn">Zatrzymaj</button>
            )}
          </div>
          <div className="rag-answer-body">
            <ReactMarkdown>{answer}</ReactMarkdown>
            {loadingAnswer && <span className="rag-cursor">▋</span>}
          </div>
        </div>
      )}

      {/* ── Aktywne filtry ── */}
      <ActiveFilters filters={filters} onRemove={removeFilter} />

      {/* ── Statystyki ── */}
      {total > 0 && !loadingDocs && (
        <p className="rag-stats">
          {total} dokumentów · strona {page}/{totalPages} · {searchTime.toFixed(2)}s
          {tags.length > 0 && <> · tagi: {tags.slice(0, 4).join(', ')}</>}
        </p>
      )}

      {/* ── Dwukolumnowy layout: sidebar + wyniki ── */}
      {(hasResults || true) && (
        <div className="rag-layout">

          {/* ── Sidebar z filtrami ── */}
          <FiltersPanel
            filters={pending}
            onChange={setPending}
            onApply={handleFiltersApply}
            onReset={handleFiltersReset}
            disabled={loadingDocs}
          />

          {/* ── Wyniki ── */}
          <div className="rag-results">

            {/* Loading skeleton */}
            {loadingDocs && (
              <>
                <div className="rag-skeleton" />
                <div className="rag-skeleton" />
                <div className="rag-skeleton" />
              </>
            )}

            {/* Karty dokumentów */}
            {!loadingDocs && docs.map((doc, i) => (
              <DocumentCard
                key={doc.doc_id ?? `${doc.signature}-${i}`}
                doc={doc}
                onClick={onDocumentClick}
              />
            ))}

            {/* Brak wyników */}
            {!loadingDocs && total === 0 && query && (
              <div className="rag-no-results">
                Brak wyników dla zapytania „{query}".
              </div>
            )}

            {/* Paginacja */}
            <Pagination page={page} totalPages={totalPages} onPage={goToPage} />
          </div>
        </div>
      )}
    </div>
  )
}
