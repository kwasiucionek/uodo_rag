#!/usr/bin/env python3
"""
update_decisions.py — delta-aktualizacja decyzji UODO.

Pobiera tylko nowe decyzje (wydane po ostatniej zaindeksowanej dacie),
scrapuje ich treść i indeksuje w OpenSearch.

Użycie:
  python tools/update_decisions.py                    # tryb automatyczny
  python tools/update_decisions.py --dry-run          # sprawdź co by zostało pobrane
  python tools/update_decisions.py --date-from 2025-01-01  # od konkretnej daty
  python tools/update_decisions.py --force-all        # przeindeksuj wszystkie

Wywołanie przez cron (codziennie o 6:00):
  0 6 * * * cd /home/kwasiucionek/Documents/DANE/RAG/UODO/NEW && \
    /home/kwasiucionek/anaconda3/bin/python tools/update_decisions.py \
    >> logs/update.log 2>&1
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import tempfile
from datetime import datetime, timedelta
from pathlib import Path

# Dodaj katalog główny projektu do ścieżki
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except ImportError:
    pass

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger(__name__)

OPENSEARCH_URL   = os.getenv("OPENSEARCH_URL",   "http://localhost:9200")
OPENSEARCH_INDEX = os.getenv("OPENSEARCH_INDEX", "uodo_decisions")
EMBED_MODEL      = os.getenv("EMBED_MODEL",      "sdadas/stella-pl-retrieval-8k")
STATE_FILE       = os.getenv("UPDATE_STATE_FILE", "tools/update_state.json")
BATCH_SIZE       = int(os.getenv("UPDATE_BATCH_SIZE", "8"))
SCRAPER_DELAY    = float(os.getenv("UPDATE_SCRAPER_DELAY", "0.5"))


# ─────────────────────────── STATE ───────────────────────────────

def load_state() -> dict:
    """Wczytuje stan ostatniej aktualizacji."""
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"last_update": None, "last_indexed_date": None, "total_indexed": 0}


def save_state(state: dict) -> None:
    """Zapisuje stan aktualizacji."""
    os.makedirs(os.path.dirname(STATE_FILE) or ".", exist_ok=True)
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


# ─────────────────────────── OPENSEARCH ──────────────────────────

def get_latest_indexed_date(client, index: str) -> str | None:
    """
    Pobiera datę najnowszej zaindeksowanej decyzji.
    Szuka po chunk_index=0 żeby nie liczyć duplikatów.
    """
    try:
        resp = client.search(
            index=index,
            body={
                "query": {
                    "bool": {
                        "must": [
                            {"term": {"doc_type":    "uodo_decision"}},
                            {"term": {"chunk_index": 0}},
                        ]
                    }
                },
                "aggs": {
                    "max_date": {"max": {"field": "date_issued"}}
                },
                "size": 0,
            },
        )
        value = resp.get("aggregations", {}).get("max_date", {}).get("value_as_string")
        if value:
            return value[:10]  # YYYY-MM-DD
    except Exception as e:
        log.warning("Błąd pobierania daty: %s", e)
    return None


def get_indexed_signatures(client, index: str) -> set[str]:
    """Pobiera zbiór sygnatur już zaindeksowanych decyzji."""
    sigs         = set()
    search_after = None

    while True:
        body: dict = {
            "query": {
                "bool": {
                    "must": [
                        {"term": {"doc_type":    "uodo_decision"}},
                        {"term": {"chunk_index": 0}},
                    ]
                }
            },
            "_source": ["signature"],
            "size":    500,
            "sort":    [{"_id": "asc"}],
        }
        if search_after:
            body["search_after"] = search_after

        resp = client.search(index=index, body=body)
        hits = resp["hits"]["hits"]
        if not hits:
            break

        for h in hits:
            sig = h["_source"].get("signature", "")
            if sig:
                sigs.add(sig)

        if len(hits) < 500:
            break
        search_after = hits[-1]["sort"]

    return sigs


def delete_decision(client, index: str, signature: str) -> int:
    """Usuwa wszystkie chunki danej decyzji (do re-indeksowania)."""
    resp = client.delete_by_query(
        index=index,
        body={
            "query": {
                "bool": {
                    "must": [
                        {"term": {"doc_type":  "uodo_decision"}},
                        {"term": {"signature": signature}},
                    ]
                }
            }
        },
        params={"refresh": "true"},
    )
    deleted = resp.get("deleted", 0)
    if deleted:
        log.info("  Usunięto %d chunków decyzji %s (re-indeksowanie)", deleted, signature)
    return deleted


# ─────────────────────────── GŁÓWNA LOGIKA ───────────────────────

def run_update(
    date_from:  str | None = None,
    date_to:    str | None = None,
    dry_run:    bool = False,
    force_all:  bool = False,
    batch_size: int  = BATCH_SIZE,
) -> dict:
    """
    Główna funkcja delta-aktualizacji.

    Zwraca słownik ze statystykami:
      new_found, new_indexed, errors, duration_s
    """
    start_time = datetime.now()
    stats = {"new_found": 0, "new_indexed": 0, "errors": 0, "duration_s": 0.0}

    # ── OpenSearch ──────────────────────────────────────────────
    from opensearchpy import OpenSearch
    client = OpenSearch(
        hosts=[OPENSEARCH_URL], timeout=60, max_retries=3, retry_on_timeout=True
    )

    if not client.indices.exists(index=OPENSEARCH_INDEX):
        log.error("Indeks '%s' nie istnieje. Uruchom najpierw pełne indeksowanie.", OPENSEARCH_INDEX)
        return stats

    # ── Ustal zakres dat ─────────────────────────────────────────
    state          = load_state()
    indexed_sigs   = get_indexed_signatures(client, OPENSEARCH_INDEX)
    total_existing = len(indexed_sigs)

    log.info("Zaindeksowanych decyzji: %d", total_existing)

    if force_all:
        effective_date_from = None
        log.info("Tryb --force-all: pobieranie wszystkich decyzji")
    elif date_from:
        effective_date_from = date_from
        log.info("Pobieranie od daty: %s", effective_date_from)
    else:
        # Automatycznie — od daty ostatniej zaindeksowanej decyzji minus 7 dni (bufor)
        latest = get_latest_indexed_date(client, OPENSEARCH_INDEX)
        if latest:
            buffer_date         = (datetime.strptime(latest, "%Y-%m-%d") - timedelta(days=7)).strftime("%Y-%m-%d")
            effective_date_from = buffer_date
            log.info("Ostatnia zaindeksowana decyzja: %s → szukam od: %s", latest, effective_date_from)
        else:
            effective_date_from = None
            log.info("Brak zaindeksowanych decyzji — pobieranie wszystkiego")

    # ── Scraping listy dokumentów ─────────────────────────────────
    from uodo_scraper import fetch_document_list, make_session, refid_to_signature

    session   = make_session()
    all_docs  = fetch_document_list(session, date_from=effective_date_from, date_to=date_to)

    # Filtruj — tylko te których nie ma w indeksie (lub force_all)
    if force_all:
        to_scrape = all_docs
    else:
        to_scrape = [
            d for d in all_docs
            if refid_to_signature(d.get("refid", "")) not in indexed_sigs
        ]

    stats["new_found"] = len(to_scrape)
    log.info("Nowych decyzji do pobrania: %d", len(to_scrape))

    if not to_scrape:
        log.info("Brak nowych decyzji. Koniec.")
        state["last_update"] = datetime.now().isoformat()
        save_state(state)
        stats["duration_s"] = (datetime.now() - start_time).total_seconds()
        return stats

    if dry_run:
        log.info("Tryb --dry-run. Pierwsze 5 sygnatur:")
        for d in to_scrape[:5]:
            sig = refid_to_signature(d.get("refid", ""))
            log.info("  %s", sig)
        stats["duration_s"] = (datetime.now() - start_time).total_seconds()
        return stats

    # ── Scraping treści ───────────────────────────────────────────
    from uodo_scraper import fetch_decision

    # Użyj tymczasowego pliku JSONL
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".jsonl", delete=False, encoding="utf-8"
    ) as tmp_f:
        tmp_path = tmp_f.name

    try:
        scraped_docs = []
        for i, doc_fields in enumerate(to_scrape, 1):
            doc_id = doc_fields.get("id", "")
            sig    = refid_to_signature(doc_fields.get("refid", ""))
            log.info("[%d/%d] Pobieranie: %s", i, len(to_scrape), sig)

            doc = fetch_decision(session, doc_id, doc_fields, delay=SCRAPER_DELAY)
            if doc.get("_error"):
                log.warning("  ❌ Błąd: %s", doc["_error"])
                stats["errors"] += 1
                continue

            scraped_docs.append(doc)
            with open(tmp_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(doc, ensure_ascii=False) + "\n")

        log.info("Pobrano %d decyzji, błędy: %d", len(scraped_docs), stats["errors"])

        if not scraped_docs:
            log.info("Brak nowych danych do zaindeksowania.")
            return stats

        # ── Indeksowanie ──────────────────────────────────────────
        log.info("Ładowanie modelu embeddingowego: %s", EMBED_MODEL)
        from sentence_transformers import SentenceTransformer
        embedder = SentenceTransformer(EMBED_MODEL, trust_remote_code=True)

        from tools.opensearch_indexer import (
            build_decision_sections,
            embed_batch,
            bulk_upsert,
        )

        to_index: list[tuple[dict, str]] = []
        for doc in scraped_docs:
            sig = doc.get("signature", "")
            if not sig:
                continue

            # Usuń stare chunki jeśli decyzja była już zaindeksowana (re-indeksowanie)
            if sig in indexed_sigs:
                delete_decision(client, OPENSEARCH_INDEX, sig)

            for payload, embed_text in build_decision_sections(doc):
                to_index.append((payload, embed_text))

        log.info("Chunki do zaindeksowania: %d", len(to_index))

        payloads = [p for p, _ in to_index]
        texts    = [t for _, t in to_index]
        vecs     = embed_batch(texts, embedder, batch_size)
        ok, err  = bulk_upsert(client, OPENSEARCH_INDEX, payloads, vecs)

        log.info("Zaindeksowano: %d chunków, błędy bulk: %d", ok, err)
        stats["new_indexed"] = len(scraped_docs)
        stats["errors"]     += err

        # ── Zaktualizuj stan ──────────────────────────────────────
        state["last_update"]        = datetime.now().isoformat()
        state["last_indexed_date"]  = max(
            (d.get("date_issued", "") for d in scraped_docs if d.get("date_issued")),
            default=state.get("last_indexed_date"),
        )
        state["total_indexed"]      = total_existing + len(scraped_docs)
        save_state(state)

        # ── Wyczyść cache search.py ───────────────────────────────
        try:
            import search
            search.get_all_tags.cache_clear()        # type: ignore[attr-defined]
            search.get_taxonomy_options.cache_clear() # type: ignore[attr-defined]
            search.get_collection_stats.cache_clear() # type: ignore[attr-defined]
            # Wymuś przebudowę grafu przy następnym zapytaniu
            search._graph_loaded = False
            if os.path.exists(search.GRAPH_PATH):
                os.remove(search.GRAPH_PATH)
            log.info("Cache search.py wyczyszczony, graf zostanie przebudowany.")
        except Exception as e:
            log.warning("Nie udało się wyczyścić cache: %s", e)

    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)

    stats["duration_s"] = (datetime.now() - start_time).total_seconds()
    log.info(
        "✅ Aktualizacja zakończona: %d nowych decyzji, %d błędów, czas: %.1fs",
        stats["new_indexed"], stats["errors"], stats["duration_s"],
    )
    return stats


# ─────────────────────────── CLI ─────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Delta-aktualizacja decyzji UODO")
    parser.add_argument("--date-from", default=None, metavar="YYYY-MM-DD",
                        help="Pobierz decyzje od tej daty (domyślnie: auto)")
    parser.add_argument("--date-to",   default=None, metavar="YYYY-MM-DD")
    parser.add_argument("--dry-run",   action="store_true",
                        help="Tylko sprawdź co by zostało pobrane")
    parser.add_argument("--force-all", action="store_true",
                        help="Przeindeksuj wszystkie decyzje")
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE)
    args = parser.parse_args()

    stats = run_update(
        date_from  = args.date_from,
        date_to    = args.date_to,
        dry_run    = args.dry_run,
        force_all  = args.force_all,
        batch_size = args.batch_size,
    )

    print(f"\nStatystyki: {json.dumps(stats, indent=2)}")
